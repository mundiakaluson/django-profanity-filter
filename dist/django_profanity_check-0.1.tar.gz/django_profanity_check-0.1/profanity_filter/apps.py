from django.apps import AppConfig


class DjangoProfanityCheckConfig(AppConfig):
    name = 'django_profanity_check'
